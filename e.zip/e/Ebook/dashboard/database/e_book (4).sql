-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2022 at 03:29 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` int(8) NOT NULL,
  `phone` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `password`, `phone`, `address`, `role`, `city`) VALUES
(3, 'harmain', '', 0, 0, 'karachi', '0', 'ksjs'),
(4, 'lamiha', '', 0, 2147483647, 'islamabad', '0', 'ksjs'),
(5, 'harmain', '', 0, 9383, 'karads', '1', ',sd  '),
(6, 'harmain', '', 0, 9383, 'karads', '1', ',sd  '),
(7, 'harmain', '', 0, 9383, 'karads', '1', ',sd  '),
(8, 'harmain', '', 0, 9383, 'karads', '1', ',sd  '),
(9, 'harmain', '', 0, 9383, 'karads', '1', ',sd  '),
(10, 'FER', '', 0, 8736, 'dmc', '0', 'kxcn'),
(11, 'FER', '', 0, 8736, 'dmc', '0', 'kxcn'),
(12, 'FER', '', 0, 8736, 'dmc', '0', 'kxcn'),
(13, 'zsjdk', '', 0, 3874, 'dlkc', '0', 'ldsmc'),
(14, 'zsjdk', '', 0, 3874, 'dlkc', '0', 'ldsmc'),
(15, 'zsjdk', '', 0, 3874, 'dlkc', '0', 'ldsmc'),
(16, 'yumm', '', 0, 7634, 'dklnff', '0', 'dfv'),
(17, 'harri', '', 0, 987, 'karachi', '1', 'karachi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
