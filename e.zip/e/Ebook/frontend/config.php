<?php
$conn = mysqli_connect("localhost" ,"root" ,"" ,"ebook") or die('connection failed');
?>